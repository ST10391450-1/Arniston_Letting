﻿namespace Arniston_Letting_Api.Services.Interfaces
{
    public interface IBreakageService
    {
    }
}
