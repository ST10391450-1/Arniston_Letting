﻿using System.ComponentModel.DataAnnotations;

namespace Arniston_Letting_API.DTOs.Auth;

public class LoginRequest
{
    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Required]
    public string Password { get; set; } = string.Empty;
}