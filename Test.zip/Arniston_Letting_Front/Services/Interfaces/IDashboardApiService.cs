﻿using Arniston_Letting_Front.Models.Dashboard;

namespace Arniston_Letting_Front.Services.Interfaces;

public interface IDashboardApiService
{
    Task<DashboardDto?> GetDashboardAsync();
}