using Arniston_Letting_Front.Models.Tasks;
using Arniston_Letting_Front.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Arniston_Letting_Front.Pages.Admin;

public class AdminTasksModel : PageModel
{
    private readonly ICleanerTaskApiService _cleanerTaskApiService;

    public AdminTasksModel(
        ICleanerTaskApiService cleanerTaskApiService)
    {
        _cleanerTaskApiService = cleanerTaskApiService;
    }

    public IEnumerable<CleanerTaskDto> Tasks { get; set; } =
        Enumerable.Empty<CleanerTaskDto>();

    public CleanerTaskDto? SelectedTask { get; set; }

    [BindProperty(SupportsGet = true)]
    public string TaskSearch { get; set; } = string.Empty;

    [BindProperty(SupportsGet = true)]
    public int? TaskId { get; set; }

    public async Task OnGetAsync()
    {
        Tasks = await _cleanerTaskApiService.GetAllAsync();

        if (!string.IsNullOrWhiteSpace(TaskSearch))
        {
            Tasks = Tasks.Where(x =>
                x.CleanerName.Contains(
                    TaskSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.LocationName.Contains(
                    TaskSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.Date.Contains(
                    TaskSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                (x.Notes?.Contains(
                    TaskSearch,
                    StringComparison.OrdinalIgnoreCase) ?? false));
        }

        if (TaskId.HasValue)
        {
            SelectedTask = Tasks.FirstOrDefault(
                x => x.CleanerTaskId == TaskId.Value);
        }
    }
}