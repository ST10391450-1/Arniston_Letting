using Arniston_Letting_Front.Models.Notifications;
using Arniston_Letting_Front.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Arniston_Letting_Front.Pages.Admin;

public class AdminNotificationsModel : PageModel
{
    private readonly INotificationApiService _notificationApiService;

    public AdminNotificationsModel(
        INotificationApiService notificationApiService)
    {
        _notificationApiService = notificationApiService;
    }

    public IEnumerable<NotificationDto> Notifications { get; set; } =
        Enumerable.Empty<NotificationDto>();

    public NotificationDto? SelectedNotification { get; set; }

    [BindProperty(SupportsGet = true)]
    public string NotificationSearch { get; set; } = string.Empty;

    [BindProperty(SupportsGet = true)]
    public int? NotificationId { get; set; }

    public async Task OnGetAsync()
    {
        Notifications = await _notificationApiService.GetAllAsync();

        if (!string.IsNullOrWhiteSpace(NotificationSearch))
        {
            Notifications = Notifications.Where(x =>
                x.Type.Contains(
                    NotificationSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.Recipient.Contains(
                    NotificationSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.Message.Contains(
                    NotificationSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.Status.Contains(
                    NotificationSearch,
                    StringComparison.OrdinalIgnoreCase));
        }

        if (NotificationId.HasValue)
        {
            SelectedNotification = Notifications.FirstOrDefault(
                x => x.NotificationId == NotificationId.Value);
        }
    }
}