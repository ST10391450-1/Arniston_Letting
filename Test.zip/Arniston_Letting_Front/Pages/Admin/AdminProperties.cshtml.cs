using Arniston_Letting_Front.Models.Properties;
using Arniston_Letting_Front.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Arniston_Letting_Front.Pages.Admin;

public class AdminPropertiesModel : PageModel
{
    private readonly IPropertyApiService _propertyApiService;

    public AdminPropertiesModel(IPropertyApiService propertyApiService)
    {
        _propertyApiService = propertyApiService;
    }

    public IEnumerable<PropertyDto> Properties { get; set; } =
        Enumerable.Empty<PropertyDto>();

    public PropertyDto? SelectedProperty { get; set; }

    [BindProperty(SupportsGet = true)]
    public string PropertySearch { get; set; } = string.Empty;

    [BindProperty(SupportsGet = true)]
    public int? PropertyId { get; set; }

    public async Task OnGetAsync()
    {
        Properties = await _propertyApiService.GetAllAsync();

        if (!string.IsNullOrWhiteSpace(PropertySearch))
        {
            Properties = Properties.Where(x =>
                x.PropertyName.Contains(
                    PropertySearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.Address.Contains(
                    PropertySearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.OwnerName.Contains(
                    PropertySearch,
                    StringComparison.OrdinalIgnoreCase));
        }

        if (PropertyId.HasValue)
        {
            SelectedProperty = Properties.FirstOrDefault(
                x => x.PropertyId == PropertyId.Value);
        }
    }
}