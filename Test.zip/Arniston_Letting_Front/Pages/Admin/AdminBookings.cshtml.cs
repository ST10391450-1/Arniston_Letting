using Arniston_Letting_Front.Models.Bookings;
using Arniston_Letting_Front.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Arniston_Letting_Front.Pages.Admin;

public class AdminBookingsModel : PageModel
{
    private readonly IBookingApiService _bookingApiService;

    public AdminBookingsModel(IBookingApiService bookingApiService)
    {
        _bookingApiService = bookingApiService;
    }

    public IEnumerable<BookingDto> Bookings { get; set; } = Enumerable.Empty<BookingDto>();

    public BookingDto? SelectedBooking { get; set; }

    [BindProperty(SupportsGet = true)]
    public string BookingSearch { get; set; } = string.Empty;

    [BindProperty(SupportsGet = true)]
    public int? BookingId { get; set; }

    public async Task OnGetAsync()
    {
        Bookings = await _bookingApiService.GetAllAsync();

        if (!string.IsNullOrWhiteSpace(BookingSearch))
        {
            Bookings = Bookings.Where(x =>
                x.PropertyName.Contains(BookingSearch, StringComparison.OrdinalIgnoreCase) ||
                x.BookerName.Contains(BookingSearch, StringComparison.OrdinalIgnoreCase));
        }

        if (BookingId.HasValue)
        {
            SelectedBooking = Bookings.FirstOrDefault(
                x => x.BookingId == BookingId.Value);
        }
    }
}