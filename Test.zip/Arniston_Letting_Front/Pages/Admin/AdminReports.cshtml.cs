using Arniston_Letting_Front.Models.Reports;
using Arniston_Letting_Front.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Arniston_Letting_Front.Pages.Admin;

public class AdminReportsModel : PageModel
{
    private readonly IReportApiService _reportApiService;

    public AdminReportsModel(IReportApiService reportApiService)
    {
        _reportApiService = reportApiService;
    }

    public IEnumerable<ReportDto> Reports { get; set; } =
        Enumerable.Empty<ReportDto>();

    public ReportDto? SelectedReport { get; set; }

    [BindProperty(SupportsGet = true)]
    public string ReportSearch { get; set; } = string.Empty;

    [BindProperty(SupportsGet = true)]
    public int? ReportId { get; set; }

    public async Task OnGetAsync()
    {
        Reports = await _reportApiService.GetAllAsync();

        if (!string.IsNullOrWhiteSpace(ReportSearch))
        {
            Reports = Reports.Where(x =>
                x.ReportType.Contains(
                    ReportSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.GeneratedBy.Contains(
                    ReportSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.Status.Contains(
                    ReportSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                (x.Description?.Contains(
                    ReportSearch,
                    StringComparison.OrdinalIgnoreCase) ?? false));
        }

        if (ReportId.HasValue)
        {
            SelectedReport = Reports.FirstOrDefault(
                x => x.ReportId == ReportId.Value);
        }
    }
}