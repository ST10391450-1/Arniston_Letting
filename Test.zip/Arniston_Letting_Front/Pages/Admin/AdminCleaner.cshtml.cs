using Arniston_Letting_Front.Models.Cleaners;
using Arniston_Letting_Front.Models.Tasks;
using Arniston_Letting_Front.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Arniston_Letting_Front.Pages.Admin;

public class AdminCleanerModel : PageModel
{
    private readonly ICleanerApiService _cleanerApiService;
    private readonly ICleanerTaskApiService _cleanerTaskApiService;

    public AdminCleanerModel(
        ICleanerApiService cleanerApiService,
        ICleanerTaskApiService cleanerTaskApiService)
    {
        _cleanerApiService = cleanerApiService;
        _cleanerTaskApiService = cleanerTaskApiService;
    }

    public IEnumerable<CleanerDto> Cleaners { get; set; } =
        Enumerable.Empty<CleanerDto>();

    public IEnumerable<CleanerTaskDto> CleanerTasks { get; set; } =
        Enumerable.Empty<CleanerTaskDto>();

    public CleanerDto? SelectedCleaner { get; set; }

    [BindProperty(SupportsGet = true)]
    public string CleanerSearch { get; set; } = string.Empty;

    [BindProperty(SupportsGet = true)]
    public int? CleanerId { get; set; }

    public async Task OnGetAsync()
    {
        Cleaners = await _cleanerApiService.GetAllAsync();

        CleanerTasks = await _cleanerTaskApiService.GetAllAsync();

        if (!string.IsNullOrWhiteSpace(CleanerSearch))
        {
            Cleaners = Cleaners.Where(x =>
                x.FullName.Contains(
                    CleanerSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.PhoneNumber.Contains(
                    CleanerSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.Email.Contains(
                    CleanerSearch,
                    StringComparison.OrdinalIgnoreCase));
        }

        if (CleanerId.HasValue)
        {
            SelectedCleaner = Cleaners.FirstOrDefault(
                x => x.CleanerId == CleanerId.Value);
        }
    }
}