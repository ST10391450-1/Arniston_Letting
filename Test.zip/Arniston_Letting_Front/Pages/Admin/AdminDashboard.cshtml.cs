using Arniston_Letting_Front.Models.Dashboard;
using Arniston_Letting_Front.Services.Interfaces;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Arniston_Letting_Front.Pages.Admin;

public class AdminDashboardModel : PageModel
{
    private readonly IDashboardApiService _dashboardApiService;

    public AdminDashboardModel(IDashboardApiService dashboardApiService)
    {
        _dashboardApiService = dashboardApiService;
    }

    public DashboardDto Dashboard { get; set; } = new();

    public async Task OnGetAsync()
    {
        var dashboard = await _dashboardApiService.GetDashboardAsync();

        if (dashboard != null)
        {
            Dashboard = dashboard;
        }
    }
}