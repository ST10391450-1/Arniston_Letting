using Arniston_Letting_Front.Models.Breakages;
using Arniston_Letting_Front.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Arniston_Letting_Front.Pages.Admin;

public class AdminBreakagesModel : PageModel
{
    private readonly IBreakageApiService _breakageApiService;

    public AdminBreakagesModel(IBreakageApiService breakageApiService)
    {
        _breakageApiService = breakageApiService;
    }

    public IEnumerable<BreakageDto> Breakages { get; set; } =
        Enumerable.Empty<BreakageDto>();

    public BreakageDto? SelectedBreakage { get; set; }

    [BindProperty(SupportsGet = true)]
    public string BreakageSearch { get; set; } = string.Empty;

    [BindProperty(SupportsGet = true)]
    public int? BreakageId { get; set; }

    public async Task OnGetAsync()
    {
        Breakages = await _breakageApiService.GetAllAsync();

        if (!string.IsNullOrWhiteSpace(BreakageSearch))
        {
            Breakages = Breakages.Where(x =>
                x.LocationName.Contains(
                    BreakageSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.ReportedBy.Contains(
                    BreakageSearch,
                    StringComparison.OrdinalIgnoreCase));
        }

        if (BreakageId.HasValue)
        {
            SelectedBreakage = Breakages.FirstOrDefault(
                x => x.BreakageId == BreakageId.Value);
        }
    }
}