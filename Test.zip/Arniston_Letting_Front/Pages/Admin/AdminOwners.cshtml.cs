using Arniston_Letting_Front.Models.Owners;
using Arniston_Letting_Front.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Arniston_Letting_Front.Pages.Admin;

public class AdminOwnersModel : PageModel
{
    private readonly IOwnerApiService _ownerApiService;

    public AdminOwnersModel(IOwnerApiService ownerApiService)
    {
        _ownerApiService = ownerApiService;
    }

    public IEnumerable<OwnerDto> Owners { get; set; } =
        Enumerable.Empty<OwnerDto>();

    public OwnerDto? SelectedOwner { get; set; }

    [BindProperty(SupportsGet = true)]
    public string OwnerSearch { get; set; } = string.Empty;

    [BindProperty(SupportsGet = true)]
    public int? OwnerId { get; set; }

    public async Task OnGetAsync()
    {
        Owners = await _ownerApiService.GetAllAsync();

        if (!string.IsNullOrWhiteSpace(OwnerSearch))
        {
            Owners = Owners.Where(x =>
                x.FullName.Contains(
                    OwnerSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.Email.Contains(
                    OwnerSearch,
                    StringComparison.OrdinalIgnoreCase) ||
                x.PhoneNumber.Contains(
                    OwnerSearch,
                    StringComparison.OrdinalIgnoreCase));
        }

        if (OwnerId.HasValue)
        {
            SelectedOwner = Owners.FirstOrDefault(
                x => x.OwnerId == OwnerId.Value);
        }
    }
}