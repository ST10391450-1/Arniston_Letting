using Arniston_Letting_Front.Models.Auth;
using Arniston_Letting_Front.Services;
using Arniston_Letting_Front.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Arniston_Letting_Front.Pages.Login
{
    public class LoginModel : PageModel
    {
        private readonly IAuthApiService _authApiService;

        public LoginModel(IAuthApiService authApiService)
        {
            _authApiService = authApiService;
        }

        [BindProperty]
        public LoginRequest LoginRequest { get; set; } = new();

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var response = await _authApiService.LoginAsync(LoginRequest);

            if (response == null || !response.Success)
            {
                ModelState.AddModelError(
                    string.Empty,
                    response?.Message ?? "Login failed.");

                return Page();
            }

            // Authentication/session handling will go here.

            return RedirectToPage("/Admin/AdminDashboard");
        }
    }
}